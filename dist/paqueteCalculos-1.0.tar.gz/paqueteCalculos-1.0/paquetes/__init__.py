#Para que una carpeta funciones como un paquete se debe crear dentro un archivo con nombre __init__.py

#Los paquetes son directorios donde se almacenarán módulos relacionados entre si

#Sirven para organizar y reutilizar los módulos

