def sumar(op1, op2):
    print("El resultado de la suma es: ", op1+op2 )

def restar(op1, op2):
    print("El resultado de la resta es: ", op1-op2 )

def multiplicar(op1, op2):
    print("El resultado de la multiplicacón es: ", op1*op2 )

def dividir(dividendo, divisor):
    print("El resultado de la división es: ", dividendo/divisor )

