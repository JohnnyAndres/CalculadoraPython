#Setup: poner la descripcion del paquete que se va a distribuir
from setuptools import setup

setup(
    name="paqueteCalculos",
    version="1.0",
    description="Paquete de operaciones matematicas basicas",
    author="Johnny",
    author_email="johnnyjojoa7@gmail.com",
    url="www.johnny.com",
    packages=["paquetes","paquetes.paqueteDistribuible"]
)

